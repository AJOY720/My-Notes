/*
  Firebase সেটআপ না করলে অ্যাপের offline/local note features চলবে।
  Online Sync চালু করতে Firebase Console থেকে Web App config কপি করে নিচের মানগুলি পূরণ করুন।
  এটি Firebase Web config; Firebase Admin/service-account key এখানে কখনও দেবেন না।
*/
window.MY_NOTE_PAD_FIREBASE_CONFIG = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  appId: "PASTE_YOUR_FIREBASE_APP_ID"
};
